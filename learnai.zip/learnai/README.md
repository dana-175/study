# LearnAI ◈

تطبيق ويب مجاني لمساعدتك على الدراسة — ارفع موادك وتعلّم بالذكاء الاصطناعي.

## المميزات

- **رفع ملفات بلا حد** — PDF، Word، صور، فيديو، وأكثر
- **فلاش كارد ذكي** — توليد تلقائي من ملفاتك + مراجعة متباعدة
- **اختبارات** — أسئلة تلقائية مع شرح ومراجع لكل إجابة
- **مناقشة المادة مع الذكاء الاصطناعي** — اسأل عن أي شيء في موادك
- **مراجع موثوقة** — مكتبة مراجع لجميع المجالات
- **مجاني تماماً وبدون قيود**

## البدء السريع

### 1. استنساخ المشروع
```bash
git clone https://github.com/your-username/learnai.git
cd learnai
```

### 2. إضافة مفتاح API

افتحي ملف `js/app.js` وابحثي عن هذا السطر:
```js
const ANTHROPIC_API_KEY = "YOUR_API_KEY";
```
استبدلي `YOUR_API_KEY` بمفتاحك من [console.anthropic.com](https://console.anthropic.com).

> ⚠️ **تحذير:** لا ترفعي مفتاح API على GitHub مباشرة.
> استخدمي متغيرات بيئة أو backend proxy في الإنتاج.

### 3. تشغيل التطبيق

افتحي `index.html` مباشرة في المتصفح — لا يحتاج server.

أو استخدمي VS Code Live Server:
```bash
# تثبيت Live Server extension في VS Code
# ثم انقري بالزر الأيمن على index.html → Open with Live Server
```

## هيكل المشروع

```
learnai/
├── index.html        # الصفحة الرئيسية
├── css/
│   └── style.css     # جميع التنسيقات
├── js/
│   └── app.js        # جميع وظائف التطبيق
└── README.md
```

## الحصول على مفتاح API

1. اذهبي إلى [console.anthropic.com](https://console.anthropic.com)
2. سجّلي أو سجّلي الدخول
3. اذهبي إلى **API Keys** → **Create Key**
4. انسخي المفتاح وضعيه في `js/app.js`

## النشر على GitHub Pages

```bash
git add .
git commit -m "first commit"
git push origin main
```
ثم في إعدادات المستودع: **Settings → Pages → Deploy from branch → main**.

## التطوير المستقبلي

- [ ] توليد بطاقات حقيقية من PDF باستخدام AI
- [ ] استخراج نص من الصور (OCR)
- [ ] مزامنة السحابة
- [ ] تطبيق موبايل
- [ ] Backend proxy لحماية مفتاح API

## الترخيص

MIT — مجاني للاستخدام والتطوير.
