/* =====================================================
   LearnAI — app.js
   =====================================================
   ⚠️  مهم: استبدلي YOUR_API_KEY بمفتاح Anthropic API
   الخاص بك. احصلي عليه من: https://console.anthropic.com
   لا ترفعي المفتاح على GitHub — استخدمي متغيرات البيئة
   أو خدمة backend proxy.
   ===================================================== */

// ─── إعدادات API ──────────────────────────────────────
// استبدلي بمفتاحك أو استخدمي proxy backend
const ANTHROPIC_API_KEY = "YOUR_API_KEY";
const API_MODEL = "claude-sonnet-4-20250514";

// ─── الحالة العامة ────────────────────────────────────
let uploadedFiles  = [];
let decks          = [];
let currentDeck    = null;
let currentCardIdx = 0;
let cardFlipped    = false;
let quizScore      = 0;
let quizIdx        = 0;
let quizAnswered   = false;
let chatHistory    = [];
let isTyping       = false;

// =====================================================
// التنقل بين التبويبات
// =====================================================
function showTab(name) {
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
  document.querySelectorAll(".nb").forEach(b => b.classList.remove("active"));

  document.getElementById(name).classList.add("active");

  const map = { home: 0, files: 1, flashcards: 2, quiz: 3, chat: 4, refs: 5 };
  document.querySelectorAll(".nb")[map[name]].classList.add("active");
}

// =====================================================
// رفع الملفات
// =====================================================
function handleUpload() {
  const input = document.createElement("input");
  input.type     = "file";
  input.multiple = true;
  input.accept   = "*/*";
  input.onchange = e => Array.from(e.target.files).forEach(addFile);
  input.click();
}

function addFile(file) {
  uploadedFiles.push(file);
  renderFiles();
  updateQuizSources();
}

function fmtSize(bytes) {
  if (bytes < 1024)          return bytes + " B";
  if (bytes < 1024 * 1024)   return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

function getExt(name) {
  return name.split(".").pop().toUpperCase();
}

function extColorClass(ext) {
  if (["PDF"].includes(ext))                          return "tb-pdf";
  if (["DOC","DOCX","PPT","PPTX","TXT"].includes(ext)) return "tb-doc";
  if (["JPG","JPEG","PNG","GIF","WEBP"].includes(ext)) return "tb-img";
  if (["MP4","MOV","AVI","MKV"].includes(ext))         return "tb-vid";
  return "tb-other";
}

function renderFiles() {
  const list = document.getElementById("file-list");

  if (uploadedFiles.length === 0) {
    list.innerHTML = `
      <div class="empty-state" style="border:0.5px dashed var(--color-border);border-radius:12px;padding:2rem">
        <div style="font-size:28px">◌</div>
        <p>لا توجد ملفات بعد — ارفع أول ملف!</p>
      </div>`;
    return;
  }

  // حساب إجمالي الحجم
  const totalBytes = uploadedFiles.reduce((s, f) => s + f.size, 0);
  document.getElementById("storage-used").textContent = fmtSize(totalBytes);

  list.innerHTML = uploadedFiles.map((f, i) => {
    const ext = getExt(f.name);
    const cls = extColorClass(ext);
    return `
      <div class="file-row">
        <div class="fi-icon ${cls}">${ext}</div>
        <div class="fi-info">
          <div class="fi-name">${f.name}</div>
          <div class="fi-meta">${fmtSize(f.size)}</div>
        </div>
        <div class="fi-actions">
          <button class="ai-action-btn btn-flash" onclick="genDeck(${i})">◧ بطاقات</button>
          <button class="ai-action-btn btn-quiz"  onclick="genQuizFromFile(${i})">◎ اختبار</button>
          <button class="ai-action-btn btn-chat"  onclick="chatAboutFile(${i})">◈ ناقش</button>
        </div>
      </div>`;
  }).join("");
}

// =====================================================
// فلاش كارد
// =====================================================
function genDeck(idx) {
  const f = uploadedFiles[idx];
  const deck = {
    name: f.name.replace(/\.[^.]+$/, ""),
    source: f.name,
    progress: 0,
    cards: [
      {
        q: `ما المحور الرئيسي الذي يتناوله هذا الملف؟`,
        a: `يتناول الملف "${f.name}" — في النسخة الكاملة سيولّد الذكاء الاصطناعي بطاقات تفصيلية من المحتوى.`,
        ref: `الملف: ${f.name}`
      },
      {
        q: `كيف تلخّص المفهوم الأساسي بكلماتك؟`,
        a: `حاول صياغة الفكرة الرئيسية بأسلوبك الخاص — هذا يعزز الفهم أكثر من الحفظ.`,
        ref: `مبدأ التعلم النشط`
      },
      {
        q: `ما النقاط الثلاث الأهم في هذا المحتوى؟`,
        a: `راجع الملف وحدد العناوين الرئيسية — الذكاء الاصطناعي سيولّد بطاقات تفصيلية بناءً على محتواك.`,
        ref: `الملف: ${f.name}`
      }
    ]
  };

  decks.push(deck);
  renderDecks();
  showTab("flashcards");
}

function renderDecks() {
  const emptyEl = document.getElementById("decks-empty-state");
  const listEl  = document.getElementById("deck-list");

  if (decks.length === 0) {
    emptyEl.style.display = "";
    listEl.classList.add("hidden");
    return;
  }

  emptyEl.style.display = "none";
  listEl.classList.remove("hidden");

  listEl.innerHTML = decks.map((d, i) => `
    <div class="deck-item" onclick="startStudy(${i})">
      <span class="di-subject">${d.source}</span>
      <div class="di-name">${d.name}</div>
      <div class="di-meta">${d.cards.length} بطاقة</div>
      <div class="prog-bar">
        <div class="prog-fill" style="width:${d.progress}%"></div>
      </div>
    </div>`).join("");
}

function startStudy(idx) {
  currentDeck    = decks[idx];
  currentCardIdx = 0;
  cardFlipped    = false;

  document.getElementById("deck-list-view").style.display = "none";
  document.getElementById("study-view").classList.add("active");
  loadCard();
}

function exitStudy() {
  document.getElementById("deck-list-view").style.display = "";
  document.getElementById("study-view").classList.remove("active");
}

function loadCard() {
  if (!currentDeck) return;
  const c = currentDeck.cards[currentCardIdx];

  document.getElementById("fc-text").textContent  = c.q;
  document.getElementById("fc-label").textContent = "السؤال";
  document.getElementById("fc-hint").textContent  = "انقر لرؤية الإجابة";
  document.getElementById("fc-ref").classList.add("hidden");
  document.getElementById("fc-source").textContent = currentDeck.source;
  document.getElementById("study-prog").textContent =
    `البطاقة ${currentCardIdx + 1} من ${currentDeck.cards.length}`;

  document.getElementById("sa-show").classList.remove("hidden");
  document.getElementById("sa-rate").classList.add("hidden");
  cardFlipped = false;
}

function flipFC() {
  if (!currentDeck) return;
  cardFlipped = !cardFlipped;
  const c = currentDeck.cards[currentCardIdx];

  if (cardFlipped) {
    document.getElementById("fc-text").textContent  = c.a;
    document.getElementById("fc-label").textContent = "الإجابة";
    document.getElementById("fc-hint").textContent  = "كيف كانت إجابتك؟";

    const refEl = document.getElementById("fc-ref");
    refEl.innerHTML = `مرجع: ${c.ref}`;
    refEl.classList.remove("hidden");

    document.getElementById("sa-show").classList.add("hidden");
    document.getElementById("sa-rate").classList.remove("hidden");
  } else {
    loadCard();
  }
}

function nextFC() {
  if (!currentDeck) return;
  currentCardIdx = (currentCardIdx + 1) % currentDeck.cards.length;
  currentDeck.progress = Math.round((currentCardIdx / currentDeck.cards.length) * 100);
  loadCard();
  renderDecks();
}

// =====================================================
// الاختبارات (Quiz)
// =====================================================
function updateQuizSources() {
  const sel  = document.getElementById("quiz-source");
  const prev = sel.value;
  sel.innerHTML = '<option value="">— اختر مصدر الأسئلة —</option>';
  uploadedFiles.forEach((f, i) => {
    const opt = document.createElement("option");
    opt.value       = i;
    opt.textContent = f.name;
    sel.appendChild(opt);
  });
  if (prev) sel.value = prev;
}

function genQuizFromFile(idx) {
  document.getElementById("quiz-source").value = idx;
  showTab("quiz");
}

function startQuiz() {
  const src = document.getElementById("quiz-source").value;
  if (src === "") {
    alert("اختر ملفاً أولاً لتوليد أسئلة من موادك!");
    return;
  }

  const fname = uploadedFiles[parseInt(src)].name;
  quizScore   = 0;
  quizIdx     = 0;
  quizAnswered = false;

  document.getElementById("quiz-setup").classList.add("hidden");
  document.getElementById("quiz-active").classList.add("on");

  document.getElementById("q-text").textContent =
    `بناءً على الملف "${fname}" — في النسخة الكاملة يولّد الذكاء الاصطناعي أسئلة من محتوى ملفك. إليك مثال:`;
  document.getElementById("q-source-label").textContent = `المصدر: ${fname}`;
  document.getElementById("q-score").textContent = "الصحيح: 0";

  const total = document.getElementById("quiz-count").value;
  document.getElementById("q-num").textContent = `السؤال 1 من ${total}`;

  renderQuizOptions();
  document.getElementById("q-explain").style.display = "none";
  document.getElementById("q-ref").classList.add("hidden");
  document.getElementById("q-next-btn").style.display = "none";
}

function renderQuizOptions() {
  const opts = document.getElementById("q-opts");
  const options = ["أ. الخيار الأول", "ب. الخيار الثاني", "ج. الخيار الصحيح", "د. الخيار الرابع"];
  opts.innerHTML = options.map((o, i) =>
    `<button class="q-opt" onclick="selectAns(this, ${i === 2})">${o}</button>`
  ).join("");
}

function selectAns(btn, correct) {
  if (quizAnswered) return;
  quizAnswered = true;

  document.querySelectorAll(".q-opt").forEach(o => { o.disabled = true; });
  btn.classList.add(correct ? "correct" : "wrong");
  if (!correct) document.querySelectorAll(".q-opt")[2].classList.add("correct");

  if (correct) {
    quizScore++;
    document.getElementById("q-score").textContent = `الصحيح: ${quizScore}`;
  }

  const ex = document.getElementById("q-explain");
  ex.textContent =
    "الإجابة الصحيحة هي الخيار ج — في النسخة الكاملة سيشرح الذكاء الاصطناعي السبب مع إحالة للصفحة في ملفك.";
  ex.style.display = "block";

  const ref = document.getElementById("q-ref");
  ref.innerHTML =
    `للفهم الأعمق: <a href="https://openstax.org" target="_blank">OpenStax ←</a> | ` +
    `<a href="https://www.khanacademy.org" target="_blank">Khan Academy ←</a>`;
  ref.classList.remove("hidden");

  document.getElementById("q-next-btn").style.display = "";
}

function nextQ() {
  quizAnswered = false;
  quizIdx++;

  const total = parseInt(document.getElementById("quiz-count").value);
  if (quizIdx >= total) { resetQuiz(); return; }

  document.getElementById("q-num").textContent = `السؤال ${quizIdx + 1} من ${total}`;
  renderQuizOptions();
  document.getElementById("q-explain").style.display = "none";
  document.getElementById("q-ref").classList.add("hidden");
  document.getElementById("q-next-btn").style.display = "none";
}

function resetQuiz() {
  document.getElementById("quiz-setup").classList.remove("hidden");
  document.getElementById("quiz-active").classList.remove("on");
  quizScore = 0;
  quizIdx   = 0;
}

// =====================================================
// المحادثة مع الذكاء الاصطناعي
// =====================================================
function chatAboutFile(idx) {
  const f = uploadedFiles[idx];
  document.getElementById("chat-file-tag").textContent = `ملف: ${f.name}`;
  document.getElementById("chat-title").textContent    =
    `مناقشة: ${f.name.replace(/\.[^.]+$/, "")}`;

  document.getElementById("messages").innerHTML = `
    <div class="msg msg-ai">
      تم تحميل الملف "${f.name}" — اسألني عن أي شيء فيه!
      <div class="msg-ref">مصدر: ${f.name}</div>
    </div>`;

  chatHistory = [];
  showTab("chat");
}

function selectTopic(el, name, file) {
  document.querySelectorAll(".cs-topic").forEach(t => t.classList.remove("active"));
  el.classList.add("active");

  document.getElementById("chat-title").textContent    = name;
  document.getElementById("chat-file-tag").textContent = file ? `ملف: ${file}` : "بدون ملف مرفق";

  document.getElementById("messages").innerHTML = `
    <div class="msg msg-ai">
      محادثة جديدة — اسألني عن أي شيء!
      <div class="msg-ref">مصدر: معلومات عامة</div>
    </div>`;

  chatHistory = [];
}

function newChat() {
  const topics = document.getElementById("chat-topics");
  const div    = document.createElement("div");
  div.className = "cs-topic";
  div.innerHTML = `<div class="ct-name">محادثة جديدة</div><div class="ct-sub">لا يوجد ملف</div>`;
  div.onclick   = () => selectTopic(div, "محادثة جديدة", "");
  topics.appendChild(div);
  selectTopic(div, "محادثة جديدة", "");
}

async function sendMsg() {
  const input = document.getElementById("chat-input");
  const text  = input.value.trim();
  if (!text || isTyping) return;

  input.value = "";
  const msgs  = document.getElementById("messages");

  // رسالة المستخدم
  msgs.innerHTML += `<div class="msg msg-user">${text}</div>`;

  // مؤشر الكتابة
  const typing = document.createElement("div");
  typing.className = "typing";
  typing.id        = "typing-indicator";
  typing.innerHTML = `<div class="dot"></div><div class="dot"></div><div class="dot"></div>`;
  msgs.appendChild(typing);
  msgs.scrollTop = msgs.scrollHeight;

  isTyping = true;
  chatHistory.push({ role: "user", content: text });

  const sysPrompt = `أنت مساعد تعليمي ذكي. مهمتك مساعدة المستخدم على فهم موادهم الدراسية.
أجب بالعربية بشكل واضح ومختصر.
في نهاية ردك أضف سطراً بهذا الشكل بالضبط:
[مرجع: اذكر مرجعاً موثوقاً مناسباً مثل Khan Academy أو Wikipedia أو OpenStax]
لا تتجاوز 120 كلمة في الإجابة.`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type":      "application/json",
        "x-api-key":         ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model:      API_MODEL,
        max_tokens: 1000,
        system:     sysPrompt,
        messages:   chatHistory
      })
    });

    const data     = await response.json();
    const fullText = data.content.map(i => i.text || "").join("");
    const refMatch = fullText.match(/\[مرجع:\s*(.+?)\]/);
    const refText  = refMatch ? refMatch[1] : "";
    const mainText = fullText.replace(/\[مرجع:.+?\]/, "").trim();

    chatHistory.push({ role: "assistant", content: fullText });

    document.getElementById("typing-indicator")?.remove();

    const refHtml = refText
      ? `<div class="msg-ref">مرجع: ${refText}</div>`
      : "";

    msgs.innerHTML += `<div class="msg msg-ai">${mainText}${refHtml}</div>`;

  } catch (err) {
    document.getElementById("typing-indicator")?.remove();
    msgs.innerHTML += `
      <div class="msg msg-ai">
        عذراً، حدث خطأ في الاتصال. تأكد من إضافة مفتاح API الصحيح في ملف js/app.js.
        <div class="msg-ref">راجع: console.anthropic.com</div>
      </div>`;
    console.error("API Error:", err);
  }

  isTyping       = false;
  msgs.scrollTop = msgs.scrollHeight;
}

// =====================================================
// المراجع
// =====================================================
function searchRefs() {
  const q = document.getElementById("ref-search-input").value.trim();
  if (!q) return;
  // في النسخة الكاملة: يمكن استدعاء API للبحث عن مراجع
  alert(`البحث عن: "${q}"\nهذه الميزة تحتاج backend — يمكن ربطها بـ Google Scholar API أو Semantic Scholar.`);
}

// زر إضافة مرجع
document.getElementById("add-ref-btn").addEventListener("click", () => {
  const title  = prompt("عنوان المرجع:");
  const author = prompt("المؤلف أو الموقع:");
  const url    = prompt("الرابط (اختياري):");
  const type   = prompt("النوع: book أو web أو video");

  if (!title) return;

  const typeMap = {
    book:  ["rc-book",  "كتاب"],
    web:   ["rc-web",   "موقع"],
    video: ["rc-video", "فيديو"]
  };

  const [cls, label] = typeMap[type] || typeMap.web;
  const linkHtml = url
    ? `<a class="rc-link" href="${url}" target="_blank">${url.replace(/https?:\/\//, "")} ←</a>`
    : "";

  const card = document.createElement("div");
  card.className = "ref-card";
  card.innerHTML = `
    <span class="rc-type ${cls}">${label}</span>
    <div class="rc-title">${title}</div>
    <div class="rc-author">${author || ""}</div>
    ${linkHtml}`;

  document.getElementById("refs-grid").appendChild(card);
});
